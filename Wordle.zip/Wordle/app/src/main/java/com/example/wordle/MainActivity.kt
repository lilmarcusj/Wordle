package com.example.wordle

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //get the word from the user
        val etWord = findViewById<EditText>(R.id.editTextWord)
        //the text view that you want to show the word
        val tvGuess1 = findViewById<TextView>(R.id.textView8)
        //get the string of the edit text
        val word = etWord.text.toString()
        //display the word in our textview
        tvGuess1.text = word

        /**
         * Parameters / Fields:
         *   wordToGuess : String - the target word the user is trying to guess
         *   guess : String - what the user entered as their guess
         *
         * Returns a String of 'O', '+', and 'X', where:
         *   'O' represents the right letter in the right place
         *   '+' represents the right letter in the wrong place
         *   'X' represents a letter not in the target word
         */
        private fun checkGuess(guess: String) : String {
            var result = ""
            for (i in 0..3) {
                val wordToGuess
                if (guess[i] == wordToGuess[i]) {
                    result += "O"
                }
                else if (guess[i] in wordToGuess) {
                    result += "+"
                }
                else {
                    result += "X"
                }
            }
            return result

        }

    }
}